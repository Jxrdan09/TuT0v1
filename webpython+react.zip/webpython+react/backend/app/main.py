from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse
from .database import engine, Base
from .routers import auth, scripts, admin, amazon, proxies, gates
from .config import settings

# Crear tablas de la base de datos
Base.metadata.create_all(bind=engine)

app = FastAPI(
    title="Script Execution Platform",
    description="Plataforma para ejecutar scripts Python y PHP con sistema de autenticación",
    version="1.0.0"
)

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Permitir todos los orígenes para hosting web
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Incluir routers
app.include_router(auth.router)
app.include_router(scripts.router)
app.include_router(admin.router)
app.include_router(amazon.router)
app.include_router(proxies.router)
app.include_router(gates.router)

@app.get("/")
async def root():
    return {"message": "Script Execution Platform API", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
